WP Bottom Delay
====
With this setting, the nozzle will stand still for a moment after printing a diagonal downward line.

![The location where the nozzle will pause](../images/wireframe_bottom_delay.svg)

While the nozzle is standing still, it will keep oozing a bit of material and produce a blob there. This blob helps to attach the saw-tooth pattern to the horizontal ring beneath it. It will improve the strength and reliability of the print.

However, adding delay adds considerably to the printing time. There are a lot of locations where the nozzle will pause then.