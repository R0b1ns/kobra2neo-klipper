Surface Energy
====
This setting describes how strong the surface energy is with the printed material. It is not meant to be changed, only prescribed by the material that is being used.

The setting is not actually used by slicing at the moment, but some printer profiles use it to determine whether to use a prime tower or not.

**The setting is not visible in Cura's interface. It can only be adjusted by the profiles.**