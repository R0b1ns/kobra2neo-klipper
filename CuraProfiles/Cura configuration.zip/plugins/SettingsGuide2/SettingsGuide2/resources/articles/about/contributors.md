Contributors
====
![This project is maintained by Ghostkeeper](../images/contributors/Ghostkeeper.png)

Programming
----
![Ghostkeeper - Version 1.1 and later](../images/contributors/Ghostkeeper.png)
![Alekseisasin - Version 1.0](../images/contributors/Alekseisasin.png)

Articles
----
![Ghostkeeper - Rewriting all content in v2.0 and many articles since](../images/contributors/Ghostkeeper.png)
![Ellecross - Basis of content in v1.0](../images/contributors/Ellecross.jpg)
![Jeroen Stevens - Basis of content in v1.0](../images/contributors/no_avatar.svg)
![Christerbeke - Article about Adaptive Layer Height](../images/contributors/Christerbeke.jpg)
![Laurent Lalliard - Minor corrections](../images/contributors/5axes.png)
![Sophist - Minor corrections](../images/contributors/Sophist.jpg)
![Yohan Pereira - Minor corrections](../images/contributors/yohan-pereira.png)
![DigitalFrost - Minor corrections](../images/contributors/DigitalFrost.jpg)

Translations
----
![Goodfeat - Russian](../images/contributors/Goodfeat.png)
![Laurent Lalliard - French](../images/contributors/5axes.png)
![Vb138 - Czech](../images/contributors/Vb138.png)
![SekIsBack - German](../images/contributors/Sekisback.jpg)
