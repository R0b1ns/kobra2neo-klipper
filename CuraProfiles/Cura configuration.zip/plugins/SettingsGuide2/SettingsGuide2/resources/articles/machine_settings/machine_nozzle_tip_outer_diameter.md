Outer Nozzle Diameter
====
This setting describes the outside diameter of the nozzle tip at its thinnest point, in the bottom.

![Dimensions of the print head](../images/head_dimensions.svg)

Other settings can use this to automatically set some defaults, such as the spacing between ironing lines.

**Since this is a machine setting, this setting is not normally visible in the settings list.**