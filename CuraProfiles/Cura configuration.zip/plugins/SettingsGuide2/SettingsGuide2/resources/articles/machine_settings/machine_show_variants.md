Show Machine Variants
====
Up until Cura 2.1, this setting used to determine whether printer definitions derived from this printer would be shown as variants of the printer in a separate drop-down.

Since Cura 2.3, this setting no longer has any effect.

**Since this is a machine setting, this setting is not normally visible in the settings list.**