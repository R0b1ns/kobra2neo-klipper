Brim Width
====
This setting adjusts the width of the brim in millimeters.

![The dimensions of the brim](../images/brim_width.svg)

A wider brim will improve adhesion to the build plate, by increasing the surface area of your print. However, it will reduce the effective print area.