Skirt Distance
====
This setting adjusts the distance between the model and the skirt.

This is the distance between the closest line of the skirt and the model. If the skirt consists of multiple lines, these additional lines will be placed further away from the model.

By keeping enough distance, the skirt won't attach to the model, reducing the elephant's feet effect.