Alternate Mesh Removal
====
When multiple meshes overlap, Cura will normally remove part of one mesh to make place for the other. With this option, the meshes will alternate layer by layer, creating a woven mix of the two.