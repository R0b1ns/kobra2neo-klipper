# Cura Measure Tool

This plugin adds a tool that can be used to make measurements on models in Cura.

The plugin lets the user select two points, either on models or on the build plate.
The distance between these two points is shown in the panel for the tool; the 
distance is shown both per axis and diagonally. 

When clicking the tool moves the closest of the two points to the cursor. Hold
down the shift key to alternate between the two points instead.